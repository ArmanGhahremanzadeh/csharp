﻿using System;
using System.Collections.Generic;

namespace StudentApp
{
    class Student
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Major { get; set; }
        public void ShowInfo()
        {
            Console.WriteLine($"ID: {ID}, Name: {Name}, Major: {Major}");
        }
    }
    class Program
    {
        static Dictionary<string, Student> students = new Dictionary<string, Student>();
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n--- منوی اصلی ---");
                Console.WriteLine("1. ورود اطلاعات دانشجو");
                Console.WriteLine("2. نمایش اطلاعات دانشجو");
                Console.WriteLine("3. حذف یک دانشجو");
                Console.WriteLine("4. خروج");
                Console.Write("انتخاب شما ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        ShowStudents();
                        break;
                    case "3":
                        RemoveStudent();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("گزینه نامعتبر است");
                        break;
                }
            }
        }
        static void AddStudent()
        {
            Console.Write("ID دانشجو ");
            string id = Console.ReadLine();

            if (students.ContainsKey(id))
            {
                Console.WriteLine("قبلاً وارد شده است");
                return;
            }

            Console.Write("نام دانشجو: ");
            string name = Console.ReadLine();
            Console.Write("رشته دانشجو: ");
            string major = Console.ReadLine();

            Student s = new Student { ID = id, Name = name, Major = major };
            students[id] = s;
            Console.WriteLine(" دانشجو با موفقیت اضافه شد");
        }

        static void ShowStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("هیچ دانشجویی ثبت نشده است.");
                return;
            }
            Console.WriteLine("\nلیست دانشجوها");
            foreach (var student in students.Values)
            {
                student.ShowInfo();
            }
        }
        static void RemoveStudent()
        {
            Console.Write("ID دانشجو برای حذف: ");
            string id = Console.ReadLine();

            if (students.Remove(id))
                Console.WriteLine("دانشجو حذف شد");
            else
                Console.WriteLine("دانشجویی با این ID یافت نشد");
        }
    }
}

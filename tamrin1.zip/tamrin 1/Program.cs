﻿using System;

class program
{
    static void Main()
    {
        Console.WriteLine("int shoa dayere:");
        double shoa = Convert.ToDouble(Console.ReadLine());

        double cricumferencev = 2 * Math.PI * shoa;
        double area = Math.PI * Math.Pow(shoa, 2);

        Console.WriteLine($"cricumferencev of the dayere:{cricumferencev}");
        Console.WriteLine($"area of the dayere:{area}");

    }
}
﻿using System;

class Program
{
    static void Main()
    {
        int evenCount = 0;
        int oddCount = 0;

        Console.WriteLine("Please enter 10 numbers:");

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Enter number {i + 1}: ");
            int number;
            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.Write("Please enter a valid integer: ");
            }

            if (number % 2 == 0)
                evenCount++;
            else
                oddCount++;
        }

        Console.WriteLine($"Number of even numbers: {evenCount}");
        Console.WriteLine($"Number of odd numbers: {oddCount}");

        Console.ReadKey();
    }
}

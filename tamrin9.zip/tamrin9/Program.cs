﻿using System;

class Program
{
    static void Main()
    {
        int[] numbers = new int[5];

        Console.WriteLine("Enter 5 numbers:");
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Number {i + 1}: ");
            numbers[i] = int.Parse(Console.ReadLine());
        }
        bool found = false;
        for (int i = 0; i < 5; i++)
        {
            if (numbers[i] == 2)
            {
                Console.WriteLine($"2 dar mogheiat  {i + 1}.");
                found = true;
                break; 
            }
        }
        if (!found)
        {
            Console.WriteLine("2 nadarim.");
        }
    }
}

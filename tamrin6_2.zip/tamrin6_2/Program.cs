﻿using System;
using System.Collections.Generic;
using System.IO;

namespace StudentApp
{
    class Student
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Major { get; set; }

        public void ShowInfo()
        {
            Console.WriteLine($"ID: {ID}, Name: {Name}, Major: {Major}");
        }

        public override string ToString()
        {
            return $"{ID},{Name},{Major}";
        }

        public static Student FromString(string line)
        {
            var parts = line.Split(',');
            if (parts.Length == 3)
                return new Student { ID = parts[0], Name = parts[1], Major = parts[2] };
            return null;
        }
    }

    class Program
    {
        static Dictionary<string, Student> students = new Dictionary<string, Student>();
        static string filePath = "UNI.txt";

        static void Main(string[] args)
        {
            LoadData();

            while (true)
            {
                Console.WriteLine("\n--- منوی اصلی ---");
                Console.WriteLine("1. ورود اطلاعات دانشجو");
                Console.WriteLine("2. نمایش اطلاعات دانشجو");
                Console.WriteLine("3. حذف یک دانشجو");
                Console.WriteLine("4. خروج");
                Console.Write("انتخاب شما: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        ShowStudents();
                        break;
                    case "3":
                        RemoveStudent();
                        break;
                    case "4":
                        SaveData();
                        return;
                    default:
                        Console.WriteLine("گزینه نامعتبر است");
                        break;
                }
            }
        }

        static void LoadData()
        {
            if (File.Exists(filePath))
            {
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var student = Student.FromString(line);
                    if (student != null)
                        students[student.ID] = student;
                }
            }
        }

        static void SaveData()
        {
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                foreach (var s in students.Values)
                {
                    sw.WriteLine(s.ToString());
                }
            }
            Console.WriteLine("✅ اطلاعات در فایل ذخیره شد.");
        }

        static void AddStudent()
        {
            Console.Write("ID دانشجو: ");
            string id = Console.ReadLine();

            if (students.ContainsKey(id))
            {
                Console.WriteLine("این دانشجو قبلاً ثبت شده است.");
                return;
            }

            Console.Write("نام دانشجو: ");
            string name = Console.ReadLine();
            Console.Write("رشته دانشجو: ");
            string major = Console.ReadLine();

            Student s = new Student { ID = id, Name = name, Major = major };
            students[id] = s;
            Console.WriteLine("✅ دانشجو با موفقیت اضافه شد.");
        }

        static void ShowStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("⚠️ هیچ دانشجویی ثبت نشده است.");
                return;
            }

            Console.WriteLine("\n📋 لیست دانشجوها:");
            foreach (var student in students.Values)
            {
                student.ShowInfo();
            }
        }

        static void RemoveStudent()
        {
            Console.Write("ID دانشجو برای حذف: ");
            string id = Console.ReadLine();

            if (students.Remove(id))
                Console.WriteLine("✅ دانشجو حذف شد.");
            else
                Console.WriteLine("❌ دانشجویی با این ID یافت نشد.");
        }
    }
}

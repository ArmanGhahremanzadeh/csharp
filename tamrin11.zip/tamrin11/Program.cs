﻿using System;

class RecursiveMultiplication
{
    public static int Multiply(int x, int y)
    {
        if (y == 0) return 0;
        return x + Multiply(x, y - 1);
    }

    static void Main()
    {
        Console.WriteLine("Enter two numbers:");
        int x = Convert.ToInt32(Console.ReadLine());
        int y = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Multiplication result: " + Multiply(x, y));
    }
}
﻿using System;

class Program
{
    static void Main()
    {
        DrawE();
        Console.WriteLine();
        DrawH();
        Console.WriteLine();
        DrawI();
    }

    static void DrawE()
    {
        string[] E = {
            "*****",
            "*    ",
            "*****",
            "*    ",
            "*****"
        };
        Console.WriteLine(string.Join("\n", E));
    }

    static void DrawH()
    {
        string[] H = {
            "*   *",
            "*   *",
            "*****",
            "*   *",
            "*   *"
        };
        Console.WriteLine(string.Join("\n", H));
    }

    static void DrawI()
    {
        string[] I = {
            "*****",
            "  *  ",
            "  *  ",
            "  *  ",
            "*****"
        };
        Console.WriteLine(string.Join("\n", I));
    }
}

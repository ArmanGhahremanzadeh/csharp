﻿using System;
using System.Diagnostics.Contracts;
class Program
{
    static void Main()
    {
        Console.WriteLine("enter number between 1 to 7");
        int day =
            Convert.ToInt32(Console.ReadLine());
        switch (day)
        {
            case 1:
                    Console.WriteLine("shanbe");
                break;
            case 2:
                    Console.WriteLine("yekshanbeh");
                break;
            case 3:
                Console.WriteLine("doshanbeh");
                break;
            case 4:
                Console.WriteLine("seshanbeh");
                break;
            case 5:
                Console.WriteLine("chaharshanbeh");
                break;
            case 6:
                Console.WriteLine("pangshanbeh");
                break;
            case 7:
                Console.WriteLine("jomeh");
                break;
            default:
                Console.WriteLine("not on list");
                break;
                
        }
    }
}
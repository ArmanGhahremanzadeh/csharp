﻿using System;

class program
{
    static void Main()
    {
        Console.WriteLine("inter dama celsius");
        double celsius = Convert.ToDouble(Console.ReadLine());

        double farenheit = (celsius * 9 / 5) + 32;

        Console.WriteLine($"dama in farenheit its: {farenheit}");
    }
}
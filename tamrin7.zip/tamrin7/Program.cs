﻿using System;

class Program
{
    static void Main()
    {
        int result = 1;
        while (true)
        {
            Console.WriteLine("enter num-0 to end");
            int num =
                Convert.ToInt32(Console.ReadLine());
            if (num == 0)
                break;
            result *= num;

        }
        Console.WriteLine("The result:" + result);
    }
}
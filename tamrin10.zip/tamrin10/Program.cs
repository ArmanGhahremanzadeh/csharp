﻿using System;

class Triangle
{
    public static double CalculatePerimeter(double a, double b, double c)
    {
        return a + b + c;
    }
    public static double CalculateArea(double a, double b, double c)
    {
        double s = (a + b + c) / 2;
        return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
    }
    static void Main()
    {
        Console.WriteLine("Enter three sides of the triangle:");
        double a = Convert.ToDouble(Console.ReadLine());
        double b = Convert.ToDouble(Console.ReadLine());
        double c = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Perimeter: " + CalculatePerimeter(a, b, c));
        Console.WriteLine("Area: " + CalculateArea(a, b, c));
    }
}